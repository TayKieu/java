package casestudy.service;

public interface BookingService extends Service{
}
