package casestudy.service;

public class ContactServiceImpl implements ContactService{
    @Override
    public void addNew() {

    }

    @Override
    public void display() {

    }

    @Override
    public void edit() {

    }
}
