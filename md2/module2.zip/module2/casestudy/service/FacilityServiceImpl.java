package casestudy.service;

public class FacilityServiceImpl implements FacilityService{
    @Override
    public void addNew() {

    }

    @Override
    public void display() {

    }

    @Override
    public void edit() {

    }
}
