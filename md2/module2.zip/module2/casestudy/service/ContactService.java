package casestudy.service;

public interface ContactService extends Service{
}
