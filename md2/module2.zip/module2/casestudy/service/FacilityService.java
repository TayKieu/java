package casestudy.service;

public interface FacilityService extends  Service{
}
