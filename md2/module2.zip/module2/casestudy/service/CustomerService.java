package casestudy.service;

public interface CustomerService extends Service{
}
