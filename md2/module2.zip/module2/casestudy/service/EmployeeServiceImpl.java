package casestudy.service;

import java.util.Scanner;

public class   EmployeeServiceImpl implements EmployeeService{
    Scanner sc = new Scanner(System.in);
    @Override
    public void addNew() {

    }

    @Override
    public void display() {

    }

    @Override
    public void edit() {

    }
}
