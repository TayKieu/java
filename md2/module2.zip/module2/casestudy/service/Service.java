package casestudy.service;

public interface Service {
    void addNew();
    void display();
    void edit();
}
