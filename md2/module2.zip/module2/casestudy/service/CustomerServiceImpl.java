package casestudy.service;

public class CustomerServiceImpl implements CustomerService{
    @Override
    public void addNew() {

    }

    @Override
    public void display() {

    }

    @Override
    public void edit() {

    }
}
