package casestudy.service;

public class BookingServiceImpl implements BookingService{
    @Override
    public void addNew() {

    }

    @Override
    public void display() {

    }

    @Override
    public void edit() {

    }
}
