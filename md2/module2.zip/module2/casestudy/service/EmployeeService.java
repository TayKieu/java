package casestudy.service;

public interface EmployeeService extends Service{
    abstract public void edit();
}
