package casestudy.models;
public class Customer extends Person {

}
