package casestudy.models;

public class Contract {
}
