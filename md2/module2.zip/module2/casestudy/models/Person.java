package casestudy.models;

public class Person {

}
