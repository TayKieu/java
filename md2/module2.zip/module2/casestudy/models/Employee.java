package casestudy.models;

public class Employee {

}
