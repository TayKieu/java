package casestudy.models;

public abstract class Facility {

}
