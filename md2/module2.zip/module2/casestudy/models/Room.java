package casestudy.models;

public class Room extends Facility {

}
