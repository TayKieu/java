package casestudy.models;

public class Booking {
}
