package casestudy.models;

import casestudy.models.Facility;

public class House extends Facility {

}
