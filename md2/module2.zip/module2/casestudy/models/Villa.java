package casestudy.models;

public class Villa extends Facility {
//    private String roomStandard;
//    private Double poolArea;
//    private Integer floorNumber;
//
//    public String getRoomStandard() {
//        return roomStandard;
//    }
//
//    public void setRoomStandard(String roomStandard) {
//        this.roomStandard = roomStandard;
//    }
//
//    public Double getPoolArea() {
//        return poolArea;
//    }
//
//    public void setPoolArea(Double poolArea) {
//        this.poolArea = poolArea;
//    }
//
//    public Integer getFloorNumber() {
//        return floorNumber;
//    }
//
//    public void setFloorNumber(Integer floorNumber) {
//        this.floorNumber = floorNumber;
//    }
}
