package bai10StackandQueue.THtrienkhaiQueueUseLinkedList;

public class Node {
    public int key;
    public Node next;

    public Node(int key) {
        this.key = key;
        this.next = null;
    }
}
