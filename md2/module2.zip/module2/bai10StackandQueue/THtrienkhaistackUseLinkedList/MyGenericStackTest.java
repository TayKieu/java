package bai10StackandQueue.THtrienkhaistackUseLinkedList;

import static bai10StackandQueue.THtrienkhaistackUseLinkedList.MyGenericStack.stackOfIStrings;
import static bai10StackandQueue.THtrienkhaistackUseLinkedList.MyGenericStack.stackOfIntegers;

public class MyGenericStackTest {
    public static void main(String[] args) {
        System.out.println("1. Stack of integers");
        stackOfIntegers();
        System.out.println("\n2. Stack of Strings");
        stackOfIStrings();
    }
}
