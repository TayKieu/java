package bai10StackandQueue.Queue;

public class Node {
    public int data;
    public Node link;
    public Node (int data){
        this.data = data;
        this.link = null;
    }
}
