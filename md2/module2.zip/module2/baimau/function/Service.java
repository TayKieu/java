package baimau.function;

public interface Service {
    abstract public void signUp();

    abstract public void edit();
    abstract public void show();
}
