package baimau.function;

public interface CreditCardService extends Service {
}
