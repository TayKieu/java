package baimau.function;

public interface ATMService extends Service {

}
