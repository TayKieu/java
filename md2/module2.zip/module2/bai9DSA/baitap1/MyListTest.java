package bai9DSA.baitap1;

public class MyListTest {
    public static void main(String[] args) {
        MyList<Integer> listInteger = new MyList<Integer>();
        listInteger.add(1);
        listInteger.add(2);
        listInteger.add(3);
        listInteger.add(4);
        listInteger.add(5);
        System.out.println(listInteger);
//        listInteger.add(2,6);
//        System.out.println(listInteger);
//        System.out.println(listInteger.contains(6));
//        listInteger.remove(2);
//        System.out.println(listInteger);
//        System.out.println(listInteger.contains(6));
//        System.out.println(listInteger.getElement(3));
    }
}
