package bai5accessmodifier.AccessModifier;

class  test {
    public static void main(String[] args) {
        Circle c1 = new Circle(5,"blue");
        System.out.println(c1.getRadius());
        System.out.println(c1.getArea());
    }
}
