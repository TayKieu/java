package bai5accessmodifier.Xaydunglopchighi;

public class Test {
    public static void main(String[] args) {
        Student st1 = new Student();
        System.out.println(st1);
        st1.setName("Tay");
        st1.setClassName("A0922I1");
        System.out.println(st1);
    }
}
