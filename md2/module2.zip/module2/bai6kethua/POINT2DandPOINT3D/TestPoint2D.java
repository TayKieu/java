package bai6kethua.POINT2DandPOINT3D;

public class TestPoint2D {
    public static void main(String[] args) {
        Point2D pointtwoD = new Point2D(3,4);
        System.out.println(pointtwoD);
    }
}
