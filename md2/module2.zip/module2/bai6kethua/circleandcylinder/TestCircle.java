package bai6kethua.circleandcylinder;

import bai6kethua.circleandcylinder.Circle;

public class TestCircle {
    public static void main(String[] args) {
        Circle circle = new Circle(5,"red");
        System.out.println(circle);
        System.out.println(circle.getArea());
    }
}
