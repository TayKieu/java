package bai6kethua.POINTvaMOVEABLEPOINT;

public class TestPoint {
    public static void main(String[] args) {
        Point point = new Point(3,4);
        System.out.println(point);
    }
}
