package bai15SuDungLopIllegalTriangleException;

public class IllegalTriangleMessage extends Throwable {
    public IllegalTriangleMessage(String message) {
        super(message);
    }

}
