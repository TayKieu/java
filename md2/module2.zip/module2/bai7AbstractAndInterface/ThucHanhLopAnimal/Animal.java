package bai7AbstractAndInterface.ThucHanhLopAnimal;

public class Animal {

}
