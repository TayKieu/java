package bai7AbstractAndInterface.colorable;

public interface Colorable {
    public void howtoColor();
}
