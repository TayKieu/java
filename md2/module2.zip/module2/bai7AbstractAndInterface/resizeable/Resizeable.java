package bai7AbstractAndInterface.resizeable;

public interface Resizeable {
        public void resize();
    }

