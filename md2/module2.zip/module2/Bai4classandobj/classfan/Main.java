package Bai4classandobj.classfan;

public class Main {
    public static void main(String[] args) {
        Fan fan1 = new Fan(4, true, 10, "yellow");
        Fan fan2 = new Fan(1, false, 10, "Blue");
        System.out.println(fan1);
        System.out.println(fan2);
    }
}
