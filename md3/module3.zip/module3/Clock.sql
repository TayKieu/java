create database quanlythoigian;
use quanlythoigian;
create table Dongho(
Name varchar(100),
Time varchar(50),
Duration int);
truncate dongho;