package service.Note;

public class INoteServiceImpl implements INoteService {
    @Override
    public boolean save() {
        return false;
    }

    @Override
    public boolean delete() {
        return false;
    }
}
