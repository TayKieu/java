package service.Note;

public interface INoteService {
    boolean save();
    boolean delete();
}
