package utils;

public class Valid {
}
