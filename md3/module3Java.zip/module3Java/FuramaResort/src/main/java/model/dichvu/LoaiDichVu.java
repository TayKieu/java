package model.dichvu;

public class LoaiDichVu {
}
