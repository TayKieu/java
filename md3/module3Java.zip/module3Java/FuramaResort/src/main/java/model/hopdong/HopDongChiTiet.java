package model.hopdong;

public class HopDongChiTiet {
}
