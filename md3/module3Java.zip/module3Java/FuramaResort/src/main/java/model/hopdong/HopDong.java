package model.hopdong;

public class HopDong {
}
