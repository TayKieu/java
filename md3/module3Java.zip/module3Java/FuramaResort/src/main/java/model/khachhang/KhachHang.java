package model.khachhang;

public class KhachHang {
}
