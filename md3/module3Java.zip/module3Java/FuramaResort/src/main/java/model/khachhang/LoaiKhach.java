package model.khachhang;

public class LoaiKhach {
}
